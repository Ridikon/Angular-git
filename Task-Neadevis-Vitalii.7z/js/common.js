/*var elem = document.getElementsByClassName('short-text');
for(var i = 0; i <= elem.length; i++){
	var str = elem[i];
	var size = 40;
	var text = str.innerHTML;
	if (text.length > size){
		text = text.slice(0, 40);
	}
	str.innerHTML = text + '...';
}*/


